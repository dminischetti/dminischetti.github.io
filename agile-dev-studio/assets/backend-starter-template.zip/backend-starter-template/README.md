# Junior Developer Starter Template

## Overview
This is a pre-configured backend environment designed to jumpstart your MVP (Minimum Viable Product). It follows industry-standard directory structures, security practices, and modern PHP development patterns.

## What's Included

### Database Layer
- **PDO-based connection** for secure database interactions
- **Prepared statements** to prevent SQL injection attacks
- **Sample schema** with Users and Tasks tables demonstrating relationships

### Security Features
- Input sanitization helpers
- XSS prevention through `htmlspecialchars()`
- CSRF protection ready (implement tokens as needed)
- Modern error handling with exceptions

### Development Tools
- Reusable helper functions for common operations
- JSON API response formatter
- Form validation utilities
- Basic CSS framework for rapid prototyping

## Setup Instructions

### 1. Database Setup
1. Open **phpMyAdmin** (or your MySQL client)
2. Import the `/sql/schema.sql` file
3. This will create the `student_project_db` database with sample tables

### 2. Configuration
1. Open `/config/db_connect.php`
2. Verify your database credentials match your local environment:
```php
   $host = 'localhost';
   $db   = 'student_project_db';
   $user = 'root';
   $pass = ''; // Update if you have a password
```

### 3. Run the Application
1. Place this folder in your server's root directory:
   - **XAMPP**: `C:\xampp\htdocs\`
   - **MAMP**: `/Applications/MAMP/htdocs/`
   - **Docker/Local**: Wherever your server points
2. Navigate to `http://localhost/backend-starter-template/`
3. You should see the welcome page with sample data

## Technical Requirements
- **PHP**: 7.4 or higher (8.x recommended)
- **MySQL**: 5.7 or higher
- **Server**: Apache or Nginx with PHP support
- **Recommended IDE**: VS Code with "PHP Intelephense" extension

## Project Structure
```
/backend-starter-template
│
├── /assets
│   ├── /css
│   │   └── style.css          # Base styles and utility classes
│   └── /js
│       └── main.js           # Client-side JavaScript helpers
│
├── /config
│   └── db_connect.php        # Database connection (PDO)
│
├── /sql
│   └── schema.sql            # Database blueprint
│
├── /src
│   └── functions.php         # Reusable PHP functions
│
├── index.php                 # Application entry point
└── README.md                 # This file
```

## Key Concepts Demonstrated

### 1. Separation of Concerns
- Configuration files separate from business logic
- CSS/JS organized in dedicated folders
- Database schema version-controlled

### 2. Security First
- PDO instead of deprecated `mysql_*` functions
- Prepared statements prevent SQL injection
- Input sanitization prevents XSS attacks

### 3. Professional Workflow
- Commented code for team collaboration
- Consistent naming conventions (snake_case for DB, camelCase for JS)
- Error handling that doesn't expose sensitive data

## Common Tasks

### Add a New Database Table
1. Edit `/sql/schema.sql`
2. Add your `CREATE TABLE` statement
3. Re-import the SQL file (or run the new statement manually)

### Create a New Page
1. Copy `index.php` to a new file (e.g., `dashboard.php`)
2. Include the config and functions at the top
3. Build your page logic

### Make an API Endpoint
```php
<?php
require_once 'config/db_connect.php';
require_once 'src/functions.php';

if (is_post_request()) {
    $data = json_decode(file_get_contents('php://input'), true);

    // Your logic here

    json_response(true, $result, 'Operation successful');
}
?>
```

## Debugging Tips
- Check PHP error logs (usually in `/xampp/apache/logs/`)
- Use the `debug()` helper function to inspect variables
- Uncomment the "Connection successful!" line in `db_connect.php` to verify DB access

## Teacher Notes
This template is designed for **grades 9-12** with basic programming knowledge. Students should understand:
- Variables, loops, and conditionals
- Basic HTML/CSS
- How to start a local server

The template handles the "boilerplate" so students can focus on **building features**, not fighting configuration issues.

## License
Free to use for educational purposes. Built by Dominic Minischetti for CTE Programming & Software Development courses.

## Support
For questions or issues, refer to the Implementation Guide provided with your course materials.
```

---

## 📦 Como Criar o ZIP

1. **Crea la struttura delle cartelle** sul tuo computer
2. **Copia ogni file** nelle rispettive posizioni
3. **Seleziona la cartella** `backend-starter-template`
4. **Comprimi** (tasto destro → "Comprimi" o usa un tool come 7-Zip)
5. **Rinomina** in `backend-starter-template.zip`

## 🎯 File Structure Finale
```
agile-dev-studio/
├── index.html
└── assets/
    ├── backend-starter-template.zip ← QUESTO FILE
    ├── project-packet.pdf
    ├── mvp-requirements-checklist.pdf
    ├── rubric.pdf
    ├── debugging-log-template.pdf
    ├── teachers-implementation-guide.pdf
    └── environment-setup-guide.pdf
