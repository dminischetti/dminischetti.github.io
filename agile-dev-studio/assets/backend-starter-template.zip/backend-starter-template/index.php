<?php

/**
 * Agile Dev Studio - Entry Point
 * Main application file
 *
 * @package AgileDevStudio
 * @author Dominic Minischetti
 */

// Include configuration and helper functions
require_once 'config/db_connect.php';
require_once 'src/functions.php';

// Start session (if needed for authentication)
session_start();

// Example: Fetch all users from database
try {
    $stmt = $pdo->query('SELECT * FROM users ORDER BY created_at DESC');
    $users = $stmt->fetchAll();
} catch (PDOException $e) {
    $users = [];
    $error_message = "Database error: " . $e->getMessage();
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Agile Dev Studio - MVP Template</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>

<body>
    <div class="container">
        <h1>Welcome to Your MVP Project</h1>

        <?php if (isset($error_message)): ?>
            <div class="alert alert-error">
                <?php echo htmlspecialchars($error_message); ?>
            </div>
        <?php endif; ?>

        <div class="card">
            <h2>Getting Started</h2>
            <p>This is your starter template. You can begin building your MVP by:</p>
            <ol>
                <li>Reviewing the database schema in <code>/sql/schema.sql</code></li>
                <li>Customizing the database connection in <code>/config/db_connect.php</code></li>
                <li>Adding your business logic using the helper functions in <code>/src/functions.php</code></li>
                <li>Building your user interface right here in <code>index.php</code></li>
            </ol>
        </div>

        <div class="card">
            <h2>Current Users in Database</h2>
            <?php if (!empty($users)): ?>
                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Username</th>
                            <th>Email</th>
                            <th>Full Name</th>
                            <th>Created At</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($users as $user): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($user['id']); ?></td>
                                <td><?php echo htmlspecialchars($user['username']); ?></td>
                                <td><?php echo htmlspecialchars($user['email']); ?></td>
                                <td><?php echo htmlspecialchars($user['full_name'] ?? 'N/A'); ?></td>
                                <td><?php echo htmlspecialchars($user['created_at']); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <p>No users found. Make sure you've imported the database schema!</p>
            <?php endif; ?>
        </div>

        <div class="card">
            <h3>Next Steps</h3>
            <ul>
                <li>✅ Database connection is ready</li>
                <li>✅ Helper functions are available</li>
                <li>✅ Basic CSS framework is in place</li>
                <li>🔨 Start building your features!</li>
            </ul>
        </div>
    </div>

    <script src="assets/js/main.js"></script>
</body>

</html>
