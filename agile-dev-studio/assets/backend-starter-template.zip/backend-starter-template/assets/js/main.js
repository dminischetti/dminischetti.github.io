/**
 * Agile Dev Studio - Client-side JavaScript
 * Base functionality for student projects
 */

// Wait for DOM to be fully loaded
document.addEventListener('DOMContentLoaded', function() {
    console.log('MVP Template loaded successfully!');

    // Initialize any interactive elements here
    initFormValidation();
});

/**
 * Basic form validation example
 */
function initFormValidation() {
    const forms = document.querySelectorAll('form[data-validate]');

    forms.forEach(form => {
        form.addEventListener('submit', function(e) {
            if (!validateForm(this)) {
                e.preventDefault();
                showAlert('Please fill in all required fields.', 'error');
            }
        });
    });
}

/**
 * Validate form fields
 * @param {HTMLFormElement} form
 * @returns {boolean}
 */
function validateForm(form) {
    const requiredFields = form.querySelectorAll('[required]');
    let isValid = true;

    requiredFields.forEach(field => {
        if (!field.value.trim()) {
            field.classList.add('error');
            isValid = false;
        } else {
            field.classList.remove('error');
        }
    });

    return isValid;
}

/**
 * Display alert message
 * @param {string} message
 * @param {string} type - 'success', 'error', or 'info'
 */
function showAlert(message, type = 'info') {
    const alertDiv = document.createElement('div');
    alertDiv.className = `alert alert-${type}`;
    alertDiv.textContent = message;

    const container = document.querySelector('.container');
    if (container) {
        container.insertBefore(alertDiv, container.firstChild);

        // Auto-remove after 5 seconds
        setTimeout(() => {
            alertDiv.remove();
        }, 5000);
    }
}

/**
 * Simple AJAX helper for API calls
 * @param {string} url
 * @param {object} data
 * @param {function} callback
 */
function apiCall(url, data, callback) {
    fetch(url, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(data)
    })
    .then(response => response.json())
    .then(data => callback(data))
    .catch(error => {
        console.error('API Error:', error);
        showAlert('An error occurred. Please try again.', 'error');
    });
}

/**
 * Format date to readable string
 * @param {string} dateString
 * @returns {string}
 */
function formatDate(dateString) {
    const options = { year: 'numeric', month: 'long', day: 'numeric' };
    return new Date(dateString).toLocaleDateString('en-US', options);
}
