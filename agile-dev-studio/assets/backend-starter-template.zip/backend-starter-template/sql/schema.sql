-- ============================================
-- Agile Dev Studio: Database Schema
-- MVP Project Starter Template
-- ============================================

CREATE DATABASE IF NOT EXISTS student_project_db
CHARACTER SET utf8mb4
COLLATE utf8mb4_unicode_ci;

USE student_project_db;

-- Example Table 1: Users
-- This table demonstrates basic user management
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    email VARCHAR(100) NOT NULL UNIQUE,
    full_name VARCHAR(100),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_username (username),
    INDEX idx_email (email)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Example Table 2: Tasks (for a simple task manager MVP)
-- Shows one-to-many relationship with users
CREATE TABLE IF NOT EXISTS tasks (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    title VARCHAR(200) NOT NULL,
    description TEXT,
    status ENUM('pending', 'in_progress', 'completed') DEFAULT 'pending',
    priority ENUM('low', 'medium', 'high') DEFAULT 'medium',
    due_date DATE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_status (status),
    INDEX idx_user_id (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Sample Data (Optional - for testing)
INSERT INTO users (username, email, full_name) VALUES
('john_doe', 'john@example.com', 'John Doe'),
('jane_smith', 'jane@example.com', 'Jane Smith');

INSERT INTO tasks (user_id, title, description, status, priority, due_date) VALUES
(1, 'Setup development environment', 'Install XAMPP and configure database', 'completed', 'high', '2024-02-01'),
(1, 'Build login page', 'Create HTML form and validation', 'in_progress', 'high', '2024-02-15'),
(2, 'Design dashboard', 'Wireframe the main user interface', 'pending', 'medium', '2024-02-20');
