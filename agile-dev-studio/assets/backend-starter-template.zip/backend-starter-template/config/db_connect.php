<?php

/**
 * Database Connection Configuration
 * Uses PDO for secure, modern database interaction
 *
 * @package AgileDevStudio
 * @author Dominic Minischetti
 */

// Database Configuration
$host = 'localhost';
$db   = 'student_project_db';
$user = 'root';
$pass = ''; // Default for local development (XAMPP/MAMP)
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false,
];

try {
    $pdo = new PDO($dsn, $user, $pass, $options);
    // Uncomment the line below for initial testing only
    // echo "Database connection successful!";
} catch (\PDOException $e) {
    // In production, log this error instead of displaying it
    throw new \PDOException($e->getMessage(), (int)$e->getCode());
}
