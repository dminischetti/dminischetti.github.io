<?php

/**
 * Helper Functions
 * Reusable utility functions for common operations
 *
 * @package AgileDevStudio
 * @author Dominic Minischetti
 */

/**
 * Sanitize user input to prevent XSS attacks
 *
 * @param string $data Raw input data
 * @return string Sanitized output
 */
function sanitize_input($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data, ENT_QUOTES, 'UTF-8');
    return $data;
}

/**
 * Validate email format
 *
 * @param string $email Email address to validate
 * @return bool True if valid, false otherwise
 */
function validate_email($email) {
    return filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
}

/**
 * Generate a simple JSON API response
 *
 * @param bool $success Success status
 * @param mixed $data Data to return
 * @param string $message Optional message
 * @return void
 */
function json_response($success, $data = null, $message = '') {
    header('Content-Type: application/json');
    echo json_encode([
        'success' => $success,
        'data' => $data,
        'message' => $message
    ], JSON_PRETTY_PRINT);
    exit;
}

/**
 * Simple debugging helper (remove in production)
 *
 * @param mixed $var Variable to debug
 * @param bool $die Whether to stop execution
 * @return void
 */
function debug($var, $die = false) {
    echo '<pre>';
    print_r($var);
    echo '</pre>';
    if ($die) die();
}

/**
 * Check if request is POST
 *
 * @return bool
 */
function is_post_request() {
    return $_SERVER['REQUEST_METHOD'] === 'POST';
}

/**
 * Check if request is GET
 *
 * @return bool
 */
function is_get_request() {
    return $_SERVER['REQUEST_METHOD'] === 'GET';
}

/**
 * Redirect to another page
 *
 * @param string $url Target URL
 * @return void
 */
function redirect($url) {
    header("Location: $url");
    exit;
}
